import pygame

class Laegen(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        original = pygame.image.load("laegen.png").convert_alpha()
        self.image = pygame.transform.scale(original, (48, 48))  # mindre læge
        self.rect = self.image.get_rect(center=pos)
        self.font = pygame.font.SysFont(None, 24)

    def talk(self, surface, game_state):
        dialog_surface = pygame.Surface((400, 100))
        dialog_surface.fill((0, 0, 0))
        pygame.draw.rect(dialog_surface, (255, 255, 255), dialog_surface.get_rect(), 2)

        if not game_state.get("nattergal_spawned"):
            text = "Du må finde den ægte nattergal!"
        elif not game_state.get("nattergal_following"):
            text = "Snak med fuglen – den må følge dig."
        else:
            text = "Skynd dig! Kejseren venter i slotsalen."

        text_surface = self.font.render(text, True, (255, 255, 255))
        dialog_surface.blit(text_surface, (10, 40))
        surface.blit(dialog_surface, (200, 450))
