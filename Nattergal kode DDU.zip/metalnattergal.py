import pygame

class MetalNattergal(pygame.sprite.Sprite):
    def __init__(self, pos, text=""):
        super().__init__()
        self.image = pygame.image.load("metalnattergal.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (50, 50))  # Gør den mindre
        self.rect = self.image.get_rect(center=pos)
        self.text = text or "Jeg er en mekanisk kopi af sangen – men jeg har ingen sjæl."
        self.font = pygame.font.SysFont(None, 24)
        self.following = False
        self.talked_to = False

    def talk(self, surface):
        dialog_surface = pygame.Surface((420, 100))
        dialog_surface.fill((30, 30, 30))
        pygame.draw.rect(dialog_surface, (255, 255, 255), dialog_surface.get_rect(), 2)
        text_surface = self.font.render(self.text, True, (255, 255, 255))
        dialog_surface.blit(text_surface, (10, 40))
        surface.blit(dialog_surface, (190, 450))
        self.talked_to = True
        self.following = True

    def follow_player(self, player_rect):
        if self.following:
            self.rect.centerx += (player_rect.centerx - self.rect.centerx) * 0.05
            self.rect.centery += (player_rect.centery - self.rect.centery) * 0.05
