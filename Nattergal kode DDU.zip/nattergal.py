import pygame
import math

class Nattergal(pygame.sprite.Sprite):
    def __init__(self, pos, text):
        super().__init__()
        original = pygame.image.load("nattergal.png").convert_alpha()
        self.image = pygame.transform.scale(original, (32, 32))  # mindre størrelse
        self.rect = self.image.get_rect(center=pos)
        self.text = text
        self.font = pygame.font.SysFont(None, 24)
        self.angle = 0
        self.center = pos
        self.following = False

    def update(self):
        if not self.following:
            # Flyv i cirkel (passiv adfærd)
            self.angle += 0.05
            radius = 30
            self.rect.centerx = self.center[0] + math.cos(self.angle) * radius
            self.rect.centery = self.center[1] + math.sin(self.angle) * radius

    def follow_player(self, player_rect):
        self.following = True
        speed = 2
        if self.rect.x < player_rect.x:
            self.rect.x += speed
        elif self.rect.x > player_rect.x:
            self.rect.x -= speed

        if self.rect.y < player_rect.y:
            self.rect.y += speed
        elif self.rect.y > player_rect.y:
            self.rect.y -= speed

    def talk(self, surface):
        dialog_surface = pygame.Surface((400, 100))
        dialog_surface.fill((0, 0, 0))
        pygame.draw.rect(dialog_surface, (255, 255, 255), dialog_surface.get_rect(), 2)
        text_surface = self.font.render(self.text, True, (255, 255, 255))
        dialog_surface.blit(text_surface, (10, 40))
        surface.blit(dialog_surface, (200, 450))
