import pygame
import sys
from player import Player
from npc import NPC
from nattergal import Nattergal
from kejseren import Kejseren
from laegen import Laegen
from troldmand import Troldmand
from metalnattergal import MetalNattergal

# Init
pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Nattergalen")

# Baggrunde
outside_background = pygame.image.load("baggrund.png").convert()
outside_background = pygame.transform.scale(outside_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

slotudefra_background = pygame.image.load("slotudefra.png").convert()
slotudefra_background = pygame.transform.scale(slotudefra_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

slot_background = pygame.image.load("slot.png").convert()
slot_background = pygame.transform.scale(slot_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

slotsal_background = pygame.image.load("slotsal.png").convert()
slotsal_background = pygame.transform.scale(slotsal_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

cutscene_image = pygame.image.load("cutscene.png").convert()
cutscene_image = pygame.transform.scale(cutscene_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

clock = pygame.time.Clock()
FPS = 60
transition_cooldown = 0
in_start_menu = True
show_cutscene = False

# Game state
def init_game_state():
    return {
        "active_quest": "find_nattergal",
        "quest_completed": False,
        "nattergal_spawned": False,
        "nattergal_following": False,
        "gave_nattergal": False,
        "metalnattergal_spawned": False,
        "metalnattergal_active": False,
        "ending": None
    }

game_state = init_game_state()
current_scene = "outside"

# Døre
door_to_slotudefra = pygame.Rect(380, 0, 40, 40)
door_back_to_outside = pygame.Rect(380, 580, 40, 20)
door_to_slot = pygame.Rect(380, 0, 40, 40)
door_back_to_slotudefra = pygame.Rect(380, 580, 40, 20)
door_to_slotsal = pygame.Rect(380, 0, 40, 40)
door_back_to_slot = pygame.Rect(380, 580, 40, 20)

# Objektgrupper og opsætning
def reset_game():
    global player, player_group, nattergal, metalnattergal, nattergal_group
    global current_scene, show_cutscene, game_state
    player = Player(pos=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
    player_group = pygame.sprite.Group(player)

    nattergal = None
    metalnattergal = None
    nattergal_group = pygame.sprite.Group()

    current_scene = "outside"
    show_cutscene = False
    game_state = init_game_state()

reset_game()

vagt = NPC(pos=(400, 450), text="Find nattergalen for at redde kejseren.", quest="find_nattergal")
npc_group = pygame.sprite.Group(vagt)

laegen = Laegen(pos=(600, 450))
laegen_group = pygame.sprite.Group(laegen)

troldmand = Troldmand(pos=(700, 450))
troldmand_group = pygame.sprite.Group(troldmand)

kejseren = Kejseren(pos=(SCREEN_WIDTH // 2, 320))
kejseren_group = pygame.sprite.Group(kejseren)

# Fade-funktion
def fade_transition(screen, text=""):
    fade_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    fade_surface.fill((0, 0, 0))
    font = pygame.font.SysFont(None, 48)
    for alpha in range(0, 300, 5):
        fade_surface.set_alpha(alpha)
        screen.blit(fade_surface, (0, 0))
        if text and alpha > 100:
            text_surface = font.render(text, True, (255, 255, 255))
            screen.blit(text_surface, text_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)))
        pygame.display.update()
        pygame.time.delay(30)

# Blinkende pil
arrow_alpha = 255
arrow_alpha_direction = -5

# Spil loop
running = True
while running:
    clock.tick(FPS)
    keys = pygame.key.get_pressed()
    if transition_cooldown > 0:
        transition_cooldown -= 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # STARTMENU
    if in_start_menu:
        screen.fill((0, 0, 0))
        font = pygame.font.SysFont(None, 48)
        screen.blit(font.render("Velkommen til Nattergalen", True, (255, 255, 255)), (200, 200))
        screen.blit(font.render("Tryk [ENTER] for at starte", True, (255, 255, 255)), (180, 300))
        pygame.display.flip()
        if keys[pygame.K_RETURN]:
            in_start_menu = False
        continue

    # SLUTSCENE
    if show_cutscene:
        font = pygame.font.SysFont(None, 36)
        screen.blit(cutscene_image, (0, 0))
        if game_state["ending"] == "bad":
            lines = [
                "Kejseren: 'Hvad... dette er ikke den ægte nattergal!'",
                "Den klikker og går i stykker...",
                "Kejseren overlever ikke.",
                "",
                "DÅRLIG SLUTNING",
                "",
                "1: Spil igen    2: Afslut"
            ]
        else:
            lines = [
                "Kejseren: 'Tak fordi du bragte nattergalen...'",
                "Den synger... og helbreder mig!",
                "Du har reddet riget fra mørket.",
                "",
                "GOD SLUTNING",
                "",
                "1: Spil igen    2: Afslut"
            ]
        for i, line in enumerate(lines):
            text_surface = font.render(line, True, (255, 255, 255))
            screen.blit(text_surface, (100, 100 + i * 40))
        pygame.display.flip()
        if keys[pygame.K_1]:
            reset_game()
            in_start_menu = True
        elif keys[pygame.K_2]:
            fade_transition(screen, text="Farvel og tak...")
            running = False
        continue

    # Opdater objekter
    player_group.update(keys)
    nattergal_group.update()
    if "nattergal" in globals() and nattergal and game_state["nattergal_following"]:
        nattergal.follow_player(player.rect)
    if "metalnattergal" in globals() and metalnattergal and game_state["metalnattergal_active"]:
        metalnattergal.follow_player(player.rect)

    show_dialog = False
    active_npc = None
    show_nattergal_dialog = False

    # --- SCENE LOGIK ---
    if current_scene == "outside":
        if player.rect.colliderect(door_to_slotudefra):
            if keys[pygame.K_e] and transition_cooldown == 0:
                fade_transition(screen, text="Du nærmer dig slottet...")
                current_scene = "slotudefra"
                player.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)
                transition_cooldown = 30

        for n in npc_group:
            if player.rect.colliderect(n.rect):
                if keys[pygame.K_e]:
                    show_dialog = True
                    active_npc = n

        if nattergal and player.rect.colliderect(nattergal.rect):
            if keys[pygame.K_e]:
                show_nattergal_dialog = True
                game_state["nattergal_following"] = True

        if metalnattergal and player.rect.colliderect(metalnattergal.rect):
            if keys[pygame.K_e]:
                show_nattergal_dialog = True
                game_state["metalnattergal_active"] = True

    elif current_scene == "slotudefra":
        if player.rect.colliderect(door_back_to_outside):
            if keys[pygame.K_e] and transition_cooldown == 0:
                fade_transition(screen, text="Du går tilbage til skoven...")
                current_scene = "outside"
                player.rect.center = (SCREEN_WIDTH // 2, 50)
                transition_cooldown = 30

        if player.rect.colliderect(door_to_slot):
            if keys[pygame.K_e] and transition_cooldown == 0:
                fade_transition(screen, text="Du går ind i slottet...")
                current_scene = "slot"
                player.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)
                transition_cooldown = 30

        if player.rect.colliderect(troldmand.rect):
            if keys[pygame.K_e]:
                show_dialog = True
                active_npc = troldmand
                if not game_state["metalnattergal_spawned"]:
                    metalnattergal = MetalNattergal(pos=(600, 400))
                    nattergal_group.add(metalnattergal)
                    game_state["metalnattergal_spawned"] = True

    elif current_scene == "slot":
        if player.rect.colliderect(door_back_to_slotudefra):
            if keys[pygame.K_e] and transition_cooldown == 0:
                fade_transition(screen, text="Du går tilbage til forgården...")
                current_scene = "slotudefra"
                player.rect.center = (SCREEN_WIDTH // 2, 50)
                transition_cooldown = 30

        if player.rect.colliderect(door_to_slotsal):
            if keys[pygame.K_e] and transition_cooldown == 0:
                fade_transition(screen, text="Du går ind i slotsalen...")
                current_scene = "slotsal"
                player.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)
                transition_cooldown = 30

        if player.rect.colliderect(laegen.rect):
            if keys[pygame.K_e]:
                show_dialog = True
                active_npc = laegen
                if not game_state["nattergal_spawned"]:
                    nattergal = Nattergal(pos=(600, 200))
                    nattergal_group.add(nattergal)
                    game_state["nattergal_spawned"] = True

    elif current_scene == "slotsal":
        if player.rect.colliderect(door_back_to_slot):
            if keys[pygame.K_e] and transition_cooldown == 0:
                fade_transition(screen, text="Du går tilbage til slottet...")
                current_scene = "slot"
                player.rect.center = (SCREEN_WIDTH // 2, 50)
                transition_cooldown = 30

        if player.rect.colliderect(kejseren.rect):
            if keys[pygame.K_e]:
                if game_state["nattergal_following"] and not game_state["gave_nattergal"]:
                    game_state["gave_nattergal"] = True
                    game_state["ending"] = "good"
                elif game_state["metalnattergal_active"] and not game_state["gave_nattergal"]:
                    game_state["gave_nattergal"] = True
                    game_state["ending"] = "bad"
                elif game_state["gave_nattergal"]:
                    show_cutscene = True

    # --- TEGN SCENER ---
    screen.fill((0, 0, 0))
    font = pygame.font.SysFont(None, 36)

    if current_scene == "outside":
        screen.blit(outside_background, (0, 0))
        npc_group.draw(screen)
        nattergal_group.draw(screen)
        player_group.draw(screen)

        arrow_alpha += arrow_alpha_direction
        if arrow_alpha <= 100 or arrow_alpha >= 255:
            arrow_alpha_direction *= -1
        arrow_surface = font.render("↑", True, (255, 255, 255))
        arrow_surface.set_alpha(arrow_alpha)
        screen.blit(arrow_surface, (390, 10))
        screen.blit(font.render("Gå mod slottet [E]", True, (255, 255, 255)), (280, 50))

        if show_dialog and active_npc:
            active_npc.talk(screen, game_state)
        if show_nattergal_dialog:
            if nattergal and game_state["nattergal_following"]:
                nattergal.talk(screen)
            elif metalnattergal and game_state["metalnattergal_active"]:
                metalnattergal.talk(screen)

    elif current_scene == "slotudefra":
        screen.blit(slotudefra_background, (0, 0))
        troldmand_group.draw(screen)
        player_group.draw(screen)
        screen.blit(font.render("Ind i slottet [E]", True, (255, 255, 255)), (300, 50))
        screen.blit(font.render("Tilbage til haven [E]", True, (255, 255, 255)), (250, 540))
        if show_dialog and active_npc:
            active_npc.talk(screen, game_state)

    elif current_scene == "slot":
        screen.blit(slot_background, (0, 0))
        laegen_group.draw(screen)
        player_group.draw(screen)
        screen.blit(font.render("Gå til slotsalen [E]", True, (255, 255, 255)), (300, 50))
        screen.blit(font.render("Tilbage til forgården [E]", True, (230, 540)))
        if show_dialog and active_npc:
            active_npc.talk(screen, game_state)

    elif current_scene == "slotsal":
        screen.blit(slotsal_background, (0, 0))
        kejseren_group.draw(screen)
        player_group.draw(screen)
        screen.blit(font.render("Tilbage til slottet [E]", True, (255, 255, 255)), (250, 540))

        if player.rect.colliderect(kejseren.rect):
            if game_state["nattergal_following"] and not game_state["gave_nattergal"]:
                screen.blit(font.render("Tryk [E] for at give nattergalen", True, (255, 255, 255)), (220, 100))
            elif game_state["metalnattergal_active"] and not game_state["gave_nattergal"]:
                screen.blit(font.render("Tryk [E] for at aflevere metalnattergal", True, (255, 255, 255)), (180, 100))
            elif game_state["gave_nattergal"]:
                if game_state["ending"] == "good":
                    screen.blit(font.render("Nattergalen synger for kejseren...", True, (255, 255, 255)), (200, 100))
                else:
                    screen.blit(font.render("Noget er galt med fuglen...", True, (255, 255, 255)), (230, 100))

    pygame.display.flip()

pygame.quit()
sys.exit()
