import pygame

class NPC(pygame.sprite.Sprite):
    def __init__(self, pos, text, quest=None):
        super().__init__()
        self.image = pygame.image.load("npc.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (50, 56))
        self.rect = self.image.get_rect(center=pos)

        self.text = text
        self.font = pygame.font.SysFont(None, 24)

        self.quest = quest
        self.quest_given = False
        self.quest_completed = False

    def talk(self, surface, game_state):
        dialog_surf = pygame.Surface((300, 100))
        dialog_surf.fill((255, 255, 200))
        pygame.draw.rect(dialog_surf, (0, 0, 0), dialog_surf.get_rect(), 2)

        if self.quest and not self.quest_given:
            text = "Vil du hjælpe med at finde nattergalen? (Tryk E)"
            self.quest_given = True
            game_state["active_quest"] = self.quest
        elif self.quest and self.quest_given and not self.quest_completed:
            text = "Har du fundet nattergalen?"
        elif self.quest and self.quest_completed:
            text = "Tak fordi du fandt den!"
        else:
            text = self.text

        text_surf = self.font.render(text, True, (0, 0, 0))
        dialog_surf.blit(text_surf, (10, 40))
        surface.blit(dialog_surf, (250, 450))
