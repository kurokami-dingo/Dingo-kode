import pygame

class Troldmand(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.image.load("troldmand.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (60, 100))  # Mindre troldmand
        self.rect = self.image.get_rect(center=pos)
        self.text = "Denne fugl er skabt af metal... Vælg med omhu."
        self.font = pygame.font.SysFont(None, 24)

    def talk(self, surface, game_state):
        dialog_surface = pygame.Surface((420, 100))
        dialog_surface.fill((0, 0, 0))
        pygame.draw.rect(dialog_surface, (255, 255, 255), dialog_surface.get_rect(), 2)
        text_surface = self.font.render(self.text, True, (255, 255, 255))
        dialog_surface.blit(text_surface, (10, 40))
        surface.blit(dialog_surface, (190, 450))
