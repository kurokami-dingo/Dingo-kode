import pygame

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()

        self.sprite_sheet = pygame.image.load("player.png").convert_alpha()
        self.frames = self.load_frames()
        self.direction = 'down'
        self.frame_index = 0
        self.animation_speed = 0.15

        self.image = self.frames[self.direction][self.frame_index]
        self.rect = self.image.get_rect(center=pos)
        self.speed = 3
        self.velocity = pygame.Vector2(0, 0)

    def load_frames(self):
        directions = ['down', 'left', 'right', 'up']
        frames = {dir: [] for dir in directions}
        width, height = 16, 18

        for row, direction in enumerate(directions):
            for col in range(3):
                frame = self.sprite_sheet.subsurface(pygame.Rect(col * width, row * height, width, height))
                frame = pygame.transform.scale(frame, (50, 56))  # skaler op
                frames[direction].append(frame)

        return frames

    def handle_input(self, keys):
        self.velocity.x = 0
        self.velocity.y = 0

        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.velocity.x = -1
            self.direction = 'left'
        elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.velocity.x = 1
            self.direction = 'right'
        elif keys[pygame.K_UP] or keys[pygame.K_w]:
            self.velocity.y = -1
            self.direction = 'up'
        elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.velocity.y = 1
            self.direction = 'down'

    def move(self):
        if self.velocity.length_squared() > 0:
            self.velocity = self.velocity.normalize()
            self.rect.x += self.velocity.x * self.speed
            self.rect.y += self.velocity.y * self.speed
            self.animate()
        else:
            self.frame_index = 1  # stillestående midterframe
            self.image = self.frames[self.direction][self.frame_index]

    def animate(self):
        self.frame_index += self.animation_speed
        if self.frame_index >= len(self.frames[self.direction]):
            self.frame_index = 0
        self.image = self.frames[self.direction][int(self.frame_index)]

    def update(self, keys):
        self.handle_input(keys)
        self.move()

    def draw(self, surface):
        surface.blit(self.image, self.rect)
